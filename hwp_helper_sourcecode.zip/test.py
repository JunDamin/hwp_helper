
# Import the tkinter module
import tkinter
from functions import set_window_position
import win32gui as wg
import win32con 

# Creating the GUI window.
root = tkinter.Tk()
root.title("Welcome to GeekForGeeks") 
root.geometry("400x240")
  
# Creating our text widget.
sample_text = tkinter.Text( root, height = 10)
sample_text.pack()
  
# Creating a tuple containing 
# the specifications of the font.
Font_tuple = ("함초롬바탕", 20, "italic bold")
  
# Parsed the specifications to the
# Text widget using .configure( ) method.
sample_text.configure(font = Font_tuple)
root.mainloop()
